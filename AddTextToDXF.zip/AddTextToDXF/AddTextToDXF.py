'''
### Information for use of AddTextToDXF ###

@author Hans-Christian Ringstad

This script was made to be used in the Bachelor Thesis Manulab spring 2020,
it will put a logo image and a text on a dxf-file template. Files used in
this program needs to be put in the same folder as the program. For the
source code Python 3.8.1 was used.

Files needed to run the program
info.csv:   Contains information for the program to add text and logo image.
            This csv-file uses ";" as seperator
	  This file will need to contain these fields;
	# Name of field # Datatype # Comment
	finalFileName   : String   : Name of the dxf file that will be created
	templateName    : String   : Name of the template to be used as background
	logoFileName    : String   : Name of the logo PNG-file
	xInsertPointLogo: float    : x-coordinate of the insert point of logo
	yInsertPointLogo: float    : y-coordinate of the insert point of logo
	xPixelSize      : int      : x length in pixels
	yPixelSize      : int      : y length in pixels
	xSizeInmm       : float    : x length in millimeter
	ySizeInmm       : float    : y length in millimeter
	rotationLogo    : float    : Rotation of logo
	textToInsert    : String   : Text to insert on the dxf file
	textStyle       : String   : Text style
	xInsertPointText: float    : x-coordinate of the insert point of text
	yInsertPointText: float    : y-coordinate of the insert point of text
	rotationText    : float    : Rotation of text
	alignmentText   : int      : Alignement for the text, see doc for more info: https://ezdxf.mozman.at/docs/dxfentities/mtext.html#ezdxf.entities.MText.dxf.attachment_point
	textWidth       : float    : Width of text fields, does not cut individual words
	textHeight      : float    : Height of text
	#               #          #

status.csv: Contains information on status of the program.
            This csv-file uses ";" as seperator
	  This file will need to contain these fields;
	# Name of field # Datatype # Comment
	working	    	: boolean  : True when active, false if inactive
	done	    	: boolean  : True when the dxf file was created succesfully
	error	    	: boolean  : True when an error has occured
	#		        #	       #

'''
import ezdxf
import os
import csv
import time

'''
Error log
'''
# TODO: Insert function to add errLog.txt

'''
 Write to status.csv
'''
waitTime = 1


def updateStatus(statusFileName, working, done, error):
    print('Start updating')
    print(' ')
    returnVal = False
    tries = 0
    while (not returnVal) & (tries < 10):
        try:
            with open(statusFileName, 'w', newline='') as csvfile:
                sep = ';'
                statusWriter = csv.writer(csvfile, delimiter=sep, quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                statusWriter.writerow(['sep=' + sep])
                statusWriter.writerow(['working', 'done', 'error'])
                statusWriter.writerow([working, done, error])
                returnVal = True
                print('Status updated')
        except PermissionError:
            returnVal = False
            tries = tries + 1
            print(str(tries) + ' Waiting...')
            print(' ')
            time.sleep(waitTime)
    if not returnVal:
        print('Status not updated')
    return returnVal


statusFileName = 'status.csv'
status = updateStatus(statusFileName, True, False, False)

'''
Read info.csv
'''

with open('info.csv') as csvfile:
    infoReader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for row in infoReader:
        info = row
info = ', '.join(info)
info = info.replace(',', '')
info = info.split(";")

'''
 Deletes the dxf file before saving the new file, also ignores exception FileNotFoundError if file does not exist
'''
dxfFileName = info[0]  # finalFileName

try:
    os.remove(dxfFileName)
except FileNotFoundError:
    pass

'''
 Get template from file and create the modelspace to add design
'''
dxfTemplateFileName = info[1]  # templateName

doc = ezdxf.readfile(dxfTemplateFileName)
msp = doc.modelspace()

'''
 Add NTNU Manulab logo
'''
logoFileName = info[2]  # logoFileName
xInsert = float(info[3])  # xInsertPointLogo
yInsert = float(info[4])  # yInsertPointLogo
xPixel = int(float(info[5]))  # xPixelSize
yPixel = int(float(info[6]))  # yPixelSize
xSize = float(info[7])  # xSizeInmm
ySize = float(info[8])  # ySizeInmm
rotLogo = float(info[9])  # rotationLogo

my_image_def = doc.add_image_def(filename=logoFileName, size_in_pixel=(xPixel, yPixel))
image = msp.add_image(image_def=my_image_def, insert=(xInsert, yInsert), size_in_units=(xSize, ySize), rotation=rotLogo)

'''
 Add name text from input
'''
textFileName = info[10]  # textToInsert
textStyle = info[11]  # textStyle

# TODO: Restrict string to 10 char per line with max 4 lines
strName = textFileName.replace('\n', ' ')

xLoc = float(info[12])  # xInsertPointText
yLoc = float(info[13])  # yInsertPointText
rotation = float(info[14])  # rotationText
alignment = int(float(info[15]))  # alignmentText
textWidth = float(info[16])  # textWidth
textHeight = float(info[17])  # textHeight

mtext = msp.add_mtext(strName, dxfattribs={'style': textStyle}).set_location((xLoc, yLoc), rotation, alignment)
mtext.dxf.width = textWidth
mtext.dxf.char_height = textHeight

'''
 Save the new file
'''
doc.saveas(dxfFileName)
